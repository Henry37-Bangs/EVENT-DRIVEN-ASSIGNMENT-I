import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;

public class SwingAssignment extends JFrame {

    private final JFrame frame;
    private final JPanel panel;
    private JLabel label;

    private final Color[] backgroundColors = {
            new Color(21, 244, 248),
            new Color(226, 28, 250),
            new Color(228, 243, 234),
            new Color(238, 233, 29),
            new Color(25, 23, 226)
    };

    private int colorIndex = 0;

    private static final Color navy = new Color(20, 32, 53);
    private static final Color mutedBlue = new Color(62, 91, 128);
    private static final Color borderBlue = new Color(160, 176, 199);
    private static final Color secondaryText = new Color(76, 94, 120);
    private static final Color white = Color.WHITE;

    private final String initialMessage =
            "Welcome to Java Swing First Individual Assignment by Henry Alusine Bangura";

    public SwingAssignment() {
        frame = this;

        setTitle("Java Swing Assignment");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(650, 650));

        // FIX 1: Use a large 128px icon for the Windows taskbar / title bar
        setIconImage(loadApplicationIcon(128).getImage());

        panel = new JPanel(new BorderLayout());
        panel.setBackground(backgroundColors[0]);

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createStatusBar(), BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(new Color(248, 250, 252));
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, borderBlue),
                BorderFactory.createEmptyBorder(14, 18, 14, 18)
        ));

        // FIX 2: Use a perfectly scaled 32px icon for the custom header
        ImageIcon headerIcon = loadApplicationIcon(60);
        JLabel iconLabel = new JLabel(headerIcon);
        // Make container a bit bigger so icon is fully visible
        iconLabel.setPreferredSize(new Dimension(60, 60));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setVerticalAlignment(SwingConstants.CENTER);

        JLabel titleLabel = new JLabel(
                "<html><b>Java Swing Assignment</b>"
                        + "<br><font size='2' color='#60738F'>"
                        + "CUSTOM ICON</font></html>"
        );
        titleLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        titleLabel.setForeground(navy);

        JPanel titleArea = new JPanel(new BorderLayout(12, 0));
        titleArea.setOpaque(false);
        titleArea.add(iconLabel, BorderLayout.WEST);
        titleArea.add(titleLabel, BorderLayout.CENTER);

        header.add(titleArea, BorderLayout.WEST);
        return header;
    }

    // ... KEEP ALL YOUR OTHER METHODS (createMainContent, createStatusBar, etc.) SAME AS BEFORE ...
    // ONLY REPLACE THE METHODS BELOW

    private JPanel createMainContent() {
        panel.setLayout(new BorderLayout());
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(72, 0, 45, 0));
        JPanel centeredContent = new JPanel(new BorderLayout());
        centeredContent.setOpaque(false);
        centeredContent.add(content, BorderLayout.CENTER);
        content.add(createSectionLabel("INDIVIDUAL ASSIGNMENT 01"));
        content.add(Box.createVerticalStrut(20));
        JLabel welcomeHeading = new JLabel("Welcome");
        welcomeHeading.setFont(new Font("SansSerif", Font.BOLD, 40));
        welcomeHeading.setForeground(navy);
        welcomeHeading.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(welcomeHeading);
        content.add(Box.createVerticalStrut(12));
        JLabel description = new JLabel("Use the controls below to update this simple event-driven interface.");
        description.setFont(new Font("SansSerif", Font.PLAIN, 14));
        description.setForeground(secondaryText);
        description.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(description);
        content.add(Box.createVerticalStrut(34));
        JPanel messageCaption = new JPanel(new BorderLayout(10, 0));
        messageCaption.setOpaque(false);
        messageCaption.setAlignmentX(Component.LEFT_ALIGNMENT);
        messageCaption.setMaximumSize(new Dimension(630, 28));
        JLabel componentTag = createTag("JLabel");
        JLabel messageTitle = new JLabel("Welcome message");
        messageTitle.setFont(new Font("SansSerif", Font.PLAIN, 11));
        messageTitle.setForeground(secondaryText);
        messageCaption.add(componentTag, BorderLayout.WEST);
        messageCaption.add(messageTitle, BorderLayout.CENTER);
        content.add(messageCaption);
        content.add(Box.createVerticalStrut(9));
        JPanel messageCard = new JPanel(new BorderLayout());
        messageCard.setBackground(white);
        messageCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderBlue, 1),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)
        ));
        messageCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        messageCard.setPreferredSize(new Dimension(630, 112));
        messageCard.setMaximumSize(new Dimension(630, 112));
        messageCard.setMinimumSize(new Dimension(300, 112));
        JPanel accent = new JPanel();
        accent.setBackground(new Color(67, 105, 157));
        accent.setPreferredSize(new Dimension(4, 112));
        messageCard.add(accent, BorderLayout.WEST);
        label = new JLabel(toHtml(initialMessage));
        label.setFont(new Font("SansSerif", Font.PLAIN, 16));
        label.setForeground(navy);
        label.setBorder(BorderFactory.createEmptyBorder(15, 27, 15, 15));
        messageCard.add(label, BorderLayout.CENTER);
        content.add(messageCard);
        content.add(Box.createVerticalStrut(38));
        JPanel divider = new JPanel();
        divider.setBackground(borderBlue);
        divider.setMaximumSize(new Dimension(630, 1));
        divider.setPreferredSize(new Dimension(630, 1));
        divider.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(divider);
        content.add(Box.createVerticalStrut(32));
        content.add(createSectionLabel("INTERACTIVE CONTROLS"));
        content.add(Box.createVerticalStrut(10));
        JPanel controlsHeading = new JPanel(new BorderLayout());
        controlsHeading.setOpaque(false);
        controlsHeading.setAlignmentX(Component.LEFT_ALIGNMENT);
        controlsHeading.setMaximumSize(new Dimension(630, 35));
        JLabel actionHeading = new JLabel("Try an action");
        actionHeading.setFont(new Font("SansSerif", Font.BOLD, 20));
        actionHeading.setForeground(navy);
        JLabel buttonCount = createTag("JBUTTON × 2");
        controlsHeading.add(actionHeading, BorderLayout.WEST);
        controlsHeading.add(buttonCount, BorderLayout.EAST);
        content.add(controlsHeading);
        content.add(Box.createVerticalStrut(12));
        JButton changeTextButton = createActionButton("Change label text", "Updates the welcome message", "T", true);
        JButton changeColorButton = createActionButton("Change panel colour", "Cycles the JPanel background", "◉", false);
        changeTextButton.addActionListener(event -> label.setText(toHtml("The label text has been changed! Welcome to Java Swing.")));
        changeColorButton.addActionListener(event -> {
            colorIndex = (colorIndex + 1) % backgroundColors.length;
            panel.setBackground(backgroundColors[colorIndex]);
            panel.repaint();
        });
        JPanel buttonRow = new JPanel(new java.awt.GridLayout(1, 2, 14, 0));
        buttonRow.setOpaque(false);
        buttonRow.add(changeTextButton);
        buttonRow.add(changeColorButton);
        content.add(buttonRow);
        JPanel contentWrapper = new JPanel(new BorderLayout());
        contentWrapper.setOpaque(false);
        contentWrapper.setBorder(BorderFactory.createEmptyBorder(0, 83, 0, 83));
        contentWrapper.add(centeredContent, BorderLayout.CENTER);
        panel.add(contentWrapper, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(248, 250, 252));
        statusBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, borderBlue),
                BorderFactory.createEmptyBorder(9, 16, 9, 16)
        ));
        JLabel statusLabel = new JLabel("<html><font color='#648A70'>●</font> <font color='#60738F'>Ready for interaction</font></html>");
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        JLabel dimensionsLabel = new JLabel("JFrame · 800 × 800");
        dimensionsLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        dimensionsLabel.setForeground(secondaryText);
        statusBar.add(statusLabel, BorderLayout.WEST);
        statusBar.add(dimensionsLabel, BorderLayout.EAST);
        return statusBar;
    }

    private JLabel createSectionLabel(String text) {
        JLabel sectionLabel = new JLabel(text);
        sectionLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        sectionLabel.setForeground(mutedBlue);
        sectionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        return sectionLabel;
    }

    private JLabel createTag(String text) {
        JLabel tag = new JLabel(text);
        tag.setFont(new Font("Monospaced", Font.BOLD, 8));
        tag.setForeground(mutedBlue);
        tag.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderBlue, 1),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return tag;
    }

    private JButton createActionButton(String title, String description, String iconText, boolean primary) {
        JButton button = new JButton("<html><b>" + title + "</b><br><font size='3'>" + description + "</font></html>");
        button.setFont(new Font("SansSerif", Font.PLAIN, 12));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setIcon(new TextIcon(iconText, primary));
        button.setIconTextGap(13);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(true);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? mutedBlue : borderBlue, 1),
                BorderFactory.createEmptyBorder(14, 16, 14, 12)
        ));
        Color normal = primary ? mutedBlue : white;
        Color foreground = primary ? white : navy;
        Color hover = primary ? new Color(49, 76, 110) : new Color(239, 244, 250);
        button.setBackground(normal);
        button.setForeground(foreground);
        button.setPreferredSize(new Dimension(300, 88));
        button.setMinimumSize(new Dimension(220, 80));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent event) { button.setBackground(hover); }
            @Override public void mouseExited(java.awt.event.MouseEvent event) { button.setBackground(normal); }
        });
        return button;
    }

    // --- THIS IS THE MAIN FIX ---
    private ImageIcon loadApplicationIcon(int targetSize) {
        URL iconURL = SwingAssignment.class.getResource("/app-icon.png");
        if (iconURL != null) {
            ImageIcon originalIcon = new ImageIcon(iconURL);
            Image originalImage = originalIcon.getImage();

            // Create a high-quality scaled version to fit perfectly
            BufferedImage scaledImage = new BufferedImage(targetSize, targetSize, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = scaledImage.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.drawImage(originalImage, 0, 0, targetSize, targetSize, null);
            g2d.dispose();

            return new ImageIcon(scaledImage);
        }
        // Fallback if app-icon.png not found
        BufferedImage image = new BufferedImage(targetSize, targetSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(248, 250, 252));
        g.fillRoundRect(1, 1, targetSize-2, targetSize-2, 10, 10);
        g.setColor(mutedBlue);
        g.drawRoundRect(1, 1, targetSize-2, targetSize-2, 10, 10);
        g.setFont(new Font("SansSerif", Font.BOLD, targetSize/2));
        g.drawString("J", targetSize/3, targetSize*2/3);
        g.dispose();
        return new ImageIcon(image);
    }

    // Keep old method for compatibility - calls new method
    private ImageIcon loadApplicationIcon() {
        return loadApplicationIcon(32);
    }

    private String toHtml(String text) {
        String escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        return "<html><body style='width: 450px;'>" + escaped + "</body></html>";
    }

    private static class TextIcon implements javax.swing.Icon {
        private final String text;
        private final boolean primary;
        TextIcon(String text, boolean primary) { this.text = text; this.primary = primary; }
        @Override public int getIconWidth() { return 36; }
        @Override public int getIconHeight() { return 36; }
        @Override public void paintIcon(Component component, java.awt.Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(primary ? new Color(65, 100, 143) : white);
            g.fillRoundRect(x, y, 36, 36, 5, 5);
            g.setColor(primary ? white : new Color(42, 61, 88));
            g.drawRoundRect(x, y, 36, 36, 5, 5);
            g.setFont(new Font("SansSerif", Font.PLAIN, 20));
            int textWidth = g.getFontMetrics().stringWidth(text);
            g.drawString(text, x + (36 - textWidth) / 2, y + 25);
            g.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SwingAssignment());
    }
}